﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ViewProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        hello.Text = (String)Session["UserName"];
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        DataView dv = (DataView)SqlDataSource1.Select(DataSourceSelectArguments.Empty);
        foreach (DataRow dr in dv.Table.Rows)
        {
            if ((String)dr["Name"] == DropDownList1.SelectedItem.ToString())
            {
                TableRow r = new TableRow();
                TableCell c1 = new TableCell();
                TableCell c2 = new TableCell();
                TableCell c3 = new TableCell();
                TableCell c4 = new TableCell();
                TableCell c5 = new TableCell();
                TableCell c6 = new TableCell();
                r.Cells.Add(c1);
                r.Cells.Add(c2);
                r.Cells.Add(c3);
                r.Cells.Add(c4);
                r.Cells.Add(c5);
                r.Cells.Add(c6);
                c1.BorderWidth = 1;
                c1.BorderColor = Color.Black;
                c1.Width = 100;
                c2.BorderWidth = 1;
                c2.BorderColor = Color.Black;
                c2.Width = 100;
                c3.BorderWidth = 1;
                c3.BorderColor = Color.Black;
                c3.Width = 400;
                c4.BorderWidth = 1;
                c4.BorderColor = Color.Black;
                c4.Width = 100;
                c5.BorderWidth = 1;
                c5.BorderColor = Color.Black;
                c5.Width = 100;
                c6.BorderWidth = 1;
                c6.BorderColor = Color.Black;
                c6.Width = 200;
                c1.Text = dr["Name"].ToString();
                c2.Text = dr["Age"].ToString();
                c3.Text = dr["Address"].ToString();
                c4.Text = dr["Telephone"].ToString();
                c5.Text = dr["Gender"].ToString();
                c6.Text = dr["E-mail address"].ToString();
                Table1.Rows.Add(r);
            }
        }
    }
}