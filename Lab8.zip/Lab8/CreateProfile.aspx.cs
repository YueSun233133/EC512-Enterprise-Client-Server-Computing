﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CreateProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        hello.Text = (String)Session["UserName"];
    }

    protected void RegisterButton_Click(object sender, EventArgs e)
    {
        if (Name.Text == "")
        {
            status.Text = "Please enter a name.";
            return;
        }
        if (Age.Text == "" )
        {
            status.Text = "Please enter age .";
            return;
        }
        
        if (Address.Text == "")
        {
            status.Text = "Please enter an address.";
            return;
        }
        if (Telephone.Text == "")
        {
            status.Text = "Please enter a telephone number.";
            return;
        }
        if (DropDownList1.SelectedItem == null)
        {
            status.Text = "Please specify gender.";
            return;
        }
        if (Email.Text == "")
        {
            status.Text = "Please enter an E-mail address.";
            return;
        }
        //Check that the user is not in the database
        DataView dv = (DataView)SqlDataSource1.Select(DataSourceSelectArguments.Empty);
        foreach (DataRow dr in dv.Table.Rows)
        {
            if ((String)dr["username"] == hello.Text)
            {
                status.Text = "User name already exists.";
                return;
            }
        }
      
        SqlDataSource1.Insert();
        status.Text = "Profile Added";
        Response.Redirect("Thankyou.aspx");

    }



    protected void SqlDataSource2_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
}