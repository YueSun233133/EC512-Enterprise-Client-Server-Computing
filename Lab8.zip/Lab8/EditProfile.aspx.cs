﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class EditeProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
        if (!IsPostBack)
        {
            Label1.Text = "";
            hello.Text = (String)Session["UserName"];
            Panel2.Visible = true;
            Panel3.Visible = false;
            Panel4.Visible = false;
            Panel5.Visible = false;
            Panel6.Visible = false;
            Panel7.Visible = false;
            Panel8.Visible = false;
            Panel9.Visible = false;

            DataView dv = (DataView)SqlDataSource1.Select(DataSourceSelectArguments.Empty);
            DataRow row = dv.Table.Rows[0];
            TextBox1.Text = Convert.ToString(row["Name"]);
            TextBox2.Text = Convert.ToString(row["Age"]);
            TextBox3.Text = Convert.ToString(row["Address"]);
            TextBox4.Text = Convert.ToString(row["Telephone"]);
            TextBox5.Text = Convert.ToString(row["Gender"]);   
            TextBox6.Text = Convert.ToString(row["E-mail address"]);
        }
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        Panel2.Visible = false;
        Panel9.Visible = true;
        if (Name.Checked)
        {
            Panel3.Visible = true;
        }
        if (Age.Checked)
        {
            Panel4.Visible = true;
        }
        if (Address.Checked)
        {
            Panel5.Visible = true;
        }
        if (Telephone.Checked)
        {
            Panel6.Visible = true;
        }
        if (Gender.Checked)
        {
            Panel7.Visible = true;
        }
        if (email.Checked)
        {
            Panel8.Visible = true;
        }

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlDataSource1.Update();
        Label1.Text = "Update completed!";
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBox5.Text = DropDownList1.SelectedValue;
    }
}