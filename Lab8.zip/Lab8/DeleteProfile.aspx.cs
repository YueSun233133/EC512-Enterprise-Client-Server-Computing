﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DeleteProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        hello.Text = (String)Session["UserName"];
        Label1.Text = "";
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlDataSource1.Delete();
        Label1.Text = "Delete completed!";
           
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
}