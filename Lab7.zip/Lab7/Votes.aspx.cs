﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;
using System.Configuration;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Votes : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        TableRow r1 = new TableRow();
        TableCell c01 = new TableCell();
        TableCell c02 = new TableCell();
        TableCell c03 = new TableCell();
        r1.Cells.Add(c01);
        r1.Cells.Add(c02);
        r1.Cells.Add(c03);
        c01.BorderWidth = 1;
        c01.BorderColor = Color.Black;
        c01.Width = 20;
        c02.BorderWidth = 1;
        c02.BorderColor = Color.Black;
        c02.Width = 100;
        c03.BorderWidth = 1;
        c03.BorderColor = Color.Black;
        c03.Width = 100;
        c01.Text = "Candidate";
        c02.Text = "Votes";
        c03.Text = "Percentage";
        Table1.Rows.Add(r1);

        DataView dv = (DataView)SqlDataSource1.Select(DataSourceSelectArguments.Empty);
        double sum = 0;
        foreach (DataRow row in dv.Table.Rows)
        {
            sum += Convert.ToDouble(row["vote"]);
        }
        foreach (DataRow dr in dv.Table.Rows)
        {
            TableRow r = new TableRow();
            TableCell c1 = new TableCell();
            TableCell c2 = new TableCell();
            TableCell c3 = new TableCell();
            r.Cells.Add(c1);
            r.Cells.Add(c2);
            r.Cells.Add(c3);
            c1.BorderWidth = 1;
            c1.BorderColor = Color.Black;
            c1.Width = 20;
            c2.BorderWidth = 1;
            c2.BorderColor = Color.Black;
            c2.Width = 100;
            c3.BorderWidth = 1;
            c3.BorderColor = Color.Black;
            c3.Width = 100;
            c1.Text = dr["candidates"].ToString();
            c2.Text = dr["vote"].ToString();
            if (sum == 0)
            {
                c3.Text = "0%";
            }
            else
            {
                double deci = (Convert.ToDouble(dr["vote"]) / sum) * 100;
                String res = deci.ToString() + "%";
                c3.Text = res;
            }
           
            Table1.Rows.Add(r);
        }
    }

}