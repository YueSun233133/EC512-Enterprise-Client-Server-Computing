﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [candidates] NVARCHAR(MAX) NOT NULL, 
    [vote] INT NOT NULL
)
